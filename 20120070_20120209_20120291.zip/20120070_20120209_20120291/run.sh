pip install numpy
python3 ./source/main.py